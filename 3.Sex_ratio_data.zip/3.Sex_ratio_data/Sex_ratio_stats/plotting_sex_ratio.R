#Basic plotting
# Load necessary libraries
# library(ggplot2)
# library(reshape2)
# library(car)
# library(tidyverse)
# library(ggpubr)
# library(rstatix)
# library(dplyr)

#Load data
maturation_matrix <- read.csv("/Users/rribeiro/Documents/Ozpolat_Lab/_Projects/Project1-SexDiff/SS-Exp40-50-60-DESEq/Statistics-final-log/Maturation-sex-ratio.csv")
data2 <- as.data.frame(maturation_matrix)
maturation_counts <- read.csv("/Users/rribeiro/Documents/Analysis/Statistics-final-log-sex-ratio/Counts_maturation.csv")
data_df <- maturation_counts

# Basic stats
  
shapiro.test (data_df$MALE)
shapiro.test (data_df$FEMALE)
sapply(data_df$MALE, mean, na.rm=TRUE)
summary(data_df$FEMALE)
summary(data_df$MALE)
sum(data_df$FEMALE, na.rm=TRUE)
sum(data_df$MALE, na.rm=TRUE)

# Cummulative sum
# Load libraries and read data from CSV file
library(ggplot2)
library(dplyr)
library(reshape2)
library(tidyverse)
library(ggpubr)
library(rstatix)

data0 <- maturation_counts # replace with your file path if necessary

# Replace NA values with 0 and calculate cumulative sum of male and female columns
data2 <- data0 %>%
  mutate(across(c(FEMALE, MALE), replace_na, 0)) %>%
  mutate(DATE = as.Date(DATE),
         cumsum_male = cumsum(MALE), cumsum_female = cumsum(FEMALE))

# Group by DATE and summarize to create new data frame
data3 <- data2 %>%
  group_by(DATE) %>%
  summarize(DATE = first(DATE),
            female = last(cumsum_female),
            male = last(cumsum_male))

# Plot the cumulative population trend
ggplot(data3, aes(x = DATE)) +
  geom_line(aes(y = male), color = "#49AD00") +
  geom_line(aes(y = female), color = "#DB009F") +
  labs(x = "Date", y = "Cumulative populations of Male to Female", color = "SEX")

# Plot the cumulative population trend with thicker lines, a legend box, and x-axis date labels every 3 months
ggplot(data3, aes(x = DATE)) +
  geom_line(aes(y = male), color = "#49AD00", size = 0.75) +
  geom_line(aes(y = female), color = "#DB009F", size = 0.75) +
  labs(x = "Date", y = "Cumulative populations of Male to Female", color = "SEX") +
  theme_bw() +
  theme(legend.position = "right",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months")

# Plot the cumulative population trend with thicker lines, a legend box, and x-axis date labels every 3 months
ggplot(data3, aes(x = DATE)) +
  geom_line(aes(y = male, color = "Male"), size = 0.75) +
  geom_line(aes(y = female, color = "Female"), size = 0.75) +
  labs(x = "Date", y = "Cumulative populations of Male to Female", color = "SEX") +
  theme_bw() +
  theme(legend.position = "right",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months") +
  scale_color_manual(values = c("Male" = "#49AD00", "Female" = "#DB009F"),
                     name = "Sex")

# 
#
#
# Calculate the cumulative sum of female and male counts and group by date
data2 <- data0 %>%
  mutate(cumsum_male = cumsum(MALE), cumsum_female = cumsum(FEMALE)) %>%
  group_by(DATE) %>%
  summarize(cumsum_male = last(cumsum_male), cumsum_female = last(cumsum_female))

## Calculate the ratio of cumulative female to cumulative male counts and add as a new column
data22 <- data2 %>%
  mutate(ratio = cumsum_female / cumsum_male)
class(data22$DATE)
data22$DATE <- as.Date(data22$DATE, format = "your_date_format")
sum(is.na(data22$DATE))
# Create a new plot using ggplot for data2 - Cumulative ratio
ggplot(data22, aes(x = DATE)) +
  geom_line(aes(y = ratio), color = "blue", size = 1) +
  labs(x = "Date", y = "Ratio of cumulative female to cumulative male counts", color = "SEX") +
  theme_bw() +
  theme(legend.position = "right",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months")



# Calculate the ratio of cumulative female to cumulative male counts and add as a new column
data23 <- data2 %>%
  mutate(diff = cumsum_female - cumsum_male)

# Create a new plot using ggplot for data2
ggplot(data23, aes(x = DATE)) +
  geom_line(aes(y = diff), color = "darkblue", size = 1) +
  labs(x = "Date", y = "Difference of cumulative female minus cumulative male counts", color = "SEX") +
  theme_bw() +
  theme(legend.position = "right",
        axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months")

#Statistical test
library(tidyverse)
library(ggpubr)
library(rstatix)

shapiro.test(data2$VALUE)
shapiro.test(data2$FEMALE)

Shapiro-Wilk normality test

data:  data2$FEMALE
W = 0.69647, p-value < 2.2e-16

shapiro.test(data2$MALE)
Shapiro-Wilk normality test

data:  data2$MALE
W = 0.69262, p-value < 2.2e-16
#Get summary of females
# A tibble: 1 × 10
variable     n   min   max median   iqr  mean    sd    se    ci
<fct>    <dbl> <dbl> <dbl>  <dbl> <dbl> <dbl> <dbl> <dbl> <dbl>
  1 FEMALE     372     0    57      3  6.25  5.50  7.71   0.4 0.786

#Get summary for male
data2 %>%
  get_summary_stats(MALE, type = "common")

# A tibble: 1 × 10
variable     n   min   max median   iqr  mean    sd    se    ci
<fct>    <dbl> <dbl> <dbl>  <dbl> <dbl> <dbl> <dbl> <dbl> <dbl>
  1 MALE       372     0    58      3     6  5.04  6.86 0.355 0.699

# Filter the data to include only the DATE, SEX, and COUNT columns
dt1 <- data2 %>% select(DATE, FEMALE, MALE)

# Pivot the data from wide format to long format
data_long1 <- dt1 %>% pivot_longer(-c(FEMALE, MALE), names_to = "COUNT_TYPE", values_to = "VALUE")

# Create a contingency table of counts by SEX and DATE
contingency_table1 <- table(data_long1$FEMALE, data_long1$MALE)

# Perform the chi-square test for independence
chi_sq_test <- chisq.test(contingency_table)

# Print the results of the test
print(chi_sq_test)

Pearsons Chi-squared test 
data:  contingency_table
X-squared = 1004, df = 720, p-value = 1.074e-11

# Calculate the cumulative sum of male and female counts for each day in the study period
data_stat <- data2
data_stat$cumsum_male <- ave(data_stat$MALE, data_stat$DATE, FUN = cumsum)
data_stat$cumsum_female <- ave(data_stat$FEMALE, data_stat$DATE, FUN = cumsum)

# Calculate the total number of individuals counted (male and female) for each day in the study period
data_stat$total_counted <- rowSums(data_stat[c("MALE", "FEMALE")])

# Calculate the proportion of males and females by dividing the cumulative sum of male or female counts by the total number of individuals counted on each day
data_stat$prop_male <- data_stat$cumsum_male / data_stat$total_counted
data_stat$prop_female <- data_stat$cumsum_female / data_stat$total_counted

# Plot the daily proportions of males and females over time using a line graph, with date on the x-axis and proportion on the y-axis. Add confidence intervals to the plot to account for variability in the estimates.
ggplot(data_stat, aes(x = DATE)) +
  geom_line(aes(y = prop_male), color = "#49AD00", size = 1) +
  geom_line(aes(y = prop_female), color = "#DB009F", size = 1) +
  labs(title = "Daily Proportion of Males and Females Over Time",
       x = "Date",
       y = "Proportion") +
  geom_ribbon(aes(ymin = prop_male - 1.96 * sqrt(prop_male * (1 - prop_male) / total_counted),
                  ymax = prop_male + 1.96 * sqrt(prop_male * (1 - prop_male) / total_counted)),
              alpha = 0.2, fill = "#49AD00") +
  geom_ribbon(aes(ymin = prop_female - 1.96 * sqrt(prop_female * (1 - prop_female) / total_counted),
                  ymax = prop_female + 1.96 * sqrt(prop_female * (1 - prop_female) / total_counted)),
              alpha = 0.2, fill = "#DB009F") +
  theme_bw()

# Use statistical tests to assess whether there is a significant difference in the proportion of males and females over time
# Chi-square test for independence
contingency_table <- table(data_stat$FEMALE, data_stat$MALE)
chi_sq_test <- chisq.test(contingency_table)
print(chi_sq_test)

# RESULTS
# Pearson's Chi-squared test

#data:  contingency_table
#X-squared = 4504.8, df = 1015, p-value < 2.2e-16



# Generalized linear mixed models
#library(lme4)
library(dplyr)
library(tidyr)
library(ggplot2)
library(car)
library(Matrix)
library(GLMMadaptive)

dt2 <-as.data.frame(data_stat)

# Fit a GLMM to estimate the daily proportion of males and females with GLMMadaptive
glmm_model <- mixed_model(cbind(MALE, FEMALE) ~ DATE + (1 | PLACE), data = dt2, family = "binomial")

fm <- mixed_model(fixed = MALE ~ FEMALE + DATE, random = ~ 1 | PLACE, data = dt2,
                  family = poisson())

summary(fm)


# Fit a GLMM to estimate the daily proportion of males and females
glmm_model <- glmer(cbind(MALE, FEMALE) ~ DATE + (1 | PLACE), data = dt2, family = "binomial")

# Calculate the confidence intervals for the estimated proportions using the GLMM model
confint_male <- exp(predict(glmm_model, newdata = data, re.form = NA, type = "response")) / sum(exp(predict(glmm_model, newdata = data, re.form = NA, type = "response")))
lower_ci_male <- apply(confint_male, 1, min)
upper_ci_male <- apply(confint_male, 1, max)
confint_female <- (exp(predict(glmm_model, newdata = data, re.form = NA, type = "response")) - confint_male) / sum(exp(predict(glmm_model, newdata = data, re.form = NA, type = "response")))
lower_ci_female <- apply(confint_female, 1, min)
upper_ci_female <- apply(confint_female, 1, max)

# Add confidence intervals to the plot
ggplot(data, aes(x = DATE)) +
  geom_line(aes(y = prop_male), color = "blue", size = 1.5) +
  geom_ribbon(aes(ymin = lower_ci_male, ymax = upper_ci_male), alpha = 0.2, fill = "blue") +
  geom_line(aes(y = prop_female), color = "red", size = 1.5) +
  geom_ribbon(aes(ymin = lower_ci_female, ymax = upper_ci_female), alpha = 0.2, fill = "red") +
  labs(title = "Daily Proportion of Males and Females Over Time",
       x = "",
       y = "Proportion") +
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months", expand = c(0, 0)) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none")

# Poisson Regression:
#   
#   If the outcome variable is a count (number of females or males).
# Useful when dealing with count data and assessing the effect of predictor variables.
# R function: glm() with family set to "poisson".
# 

glmer_model <- glmer(cbind(MALE, FEMALE) ~ DATE + (1 | PLACE), data = data_stat, family = "binomial")
summary(glmer_model)



# time series plot for males and females
library(ggplot2)
library(hrbrthemes)
str(data2)
data <- data.frame(maturation_matrix)
data.counts <- data.frame(maturation_counts)
head(data.counts)
data.counts$MALE[is.na(data.counts$MALE)] <- "NA"
data.counts$FEMALE[is.na(data.counts$MALE)] <- "NA"
data.counts$DATE <- as.Date(data.counts$DATE)
data.counts$MALE <- as.numeric(data.counts$MALE)
data.counts$FEMALE <- as.numeric(data.counts$FEMALE)

plot(MALE ~ DATE,
     data = data.counts,
     main = "Maturation",
     xlab = "DATE",
     ylab = "MALE",
     cex = 0.75,
     ylim = c(0, 60),
     xlim = as.Date(c("2021-01-01", "2024-05-01")),  # Corrected xlim
     col = "#49AD00")

points(FEMALE ~ DATE,
       data = data.counts,
       pch = 0,
       cex = 0.75,
       col = "#DB009F")


average_male <- mean(data.counts$MALE, na.rm = TRUE)
average_female <- mean(data.counts$FEMALE, na.rm = TRUE)

library(Hmisc)
ggplot(data.counts, aes(x = DATE, y = MALE)) +
  geom_point(aes(color = "Male", shape = "Male"), size = 1) +
  geom_point(aes(y = FEMALE, color = "Female", shape = "Female"), size = 1) +
  geom_hline(yintercept = average_male, linetype = "solid", color = "#49AD00") +
  geom_hline(yintercept = average_female, linetype = "solid", color = "#DB009F") +
  geom_text(aes(x = as.Date("2024-01-01"), y = average_male, label = sprintf("Avg: %.2f", average_male)),
            color = "#49AD00", vjust = -0.5, hjust = -0.5, size = 3) +  # Set font size to 3
  geom_text(aes(x = as.Date("2024-01-01"), y = average_female, label = sprintf("Avg: %.2f", average_female)),
            color = "#DB009F", vjust = 1, hjust = -0.5, size = 3) +  # Set font size to 3
  labs(title = "Maturation",
       x = "DATE",
       y = "Number of Individuals",
       color = "Gender",
       shape = "Gender") +
  scale_y_continuous(limits = c(0, 60)) +
  scale_color_manual(values = c("Male" = "#49AD00", "Female" = "#DB009F"), name = "Gender") +
  scale_shape_manual(values = c("Male" = 16, "Female" = 17), name = "Gender") +  # Set shapes for the legend
  guides(color = guide_legend(title = "Gender"),
         shape = guide_legend(title = "Gender")) +  # Customize legend titles
  coord_cartesian(xlim = as.Date(c("2021-01-01", "2024-05-01"))) +
  theme_minimal()

male_color <- "#49AD00"  # Green
female_color <- "#DB009F"  # Magenta

y_limits <- c(0, 60)  # Adjust the range as needed

# Define the smaller size and increased jitter for the data points
small_point_size <- 0.5  # Adjust the size as needed
increased_jitter <- 0.3  # Adjust the jitter width as needed


# Create a ggplot violin plot for males and females with individual data points
# Assuming your data is in the 'data.counts' data frame
# Convert the DATE column to Date type if not already
data2$DATE <- as.Date(data2$DATE)

# Load required library
library(ggplot2)
library(dplyr)

# Determine levels
data2$SEX <- factor(data2$SEX, levels = c("MALE", "FEMALE"))
data2$VALUE[is.na(data2$VALUE)] <- "NA"
data2$VALUE <- as.numeric(data2$VALUE)
data3 <- data.frame(data2)



# Define your color palette for males and females
male_color <- "#49AD00"  # Green
female_color <- "#DB009F"  # Magenta

View(data2)

#Basic violin plot
ggplot(data2, aes(x = SEX, y = VALUE, fill = SEX)) +
  geom_violin(width = 0.5, draw_quantiles = c(0.25, 0.5, 0.75), trim = FALSE) +
  geom_jitter(position = position_jitter(width = 0.1), size = 0.1, alpha = 0.7) +
  scale_fill_manual(values = c("MALE" = male_color, "FEMALE" = female_color)) +  # Set colors
  labs(title = "Violin Plot by Sex",
       x = "Sex",
       y = "Number of individuals") +
  theme_minimal()

#Include stats
# n <- sum(data2$VALUE, na.rm=TRUE)
summary(data2)
n <- aggregate(data2$VALUE, by = list(SEX=data2$SEX), FUN=sum, na.rm=T)


ggplot(data2, aes(x = SEX, y = VALUE, fill = SEX)) +
  geom_violin(width = 0.8, draw_quantiles = c(0.25, 0.5, 0.75), trim = FALSE) +
  geom_jitter(position = position_jitter(width = 0.1), size = 1, alpha = 0.7) +
  stat_summary(fun.data = function(x) mean_sdl(x, mult = 1), width = 0.2) +
  stat_summary(fun = mean, geom = "text", aes(label = paste("n =", after_stat(n$x))), vjust = -0.5, hjust=-0.5, position = position_dodge(width = 0.8)) +
  scale_fill_manual(values = c("MALE" = male_color, "FEMALE" = female_color)) +  # Set colors
  labs(title = "Violin Plot by Sex",
       x = "Sex",
       y = "Number of individuals") +
  theme_minimal()



### Ratio plot per day
library(tidyverse)
library(lubridate)

# Ensure DATE is in the correct format and FEMALE/MALE are numeric
data_df <- data_df %>%
  mutate(
    DATE = as.Date(DATE),
    FEMALE = as.numeric(FEMALE),
    MALE = as.numeric(MALE)
  )

# Step 1: Sum by month for male and female, ignoring NA values
plot_data <- data_df %>%
  mutate(MONTH = floor_date(DATE, "month")) %>%
  group_by(MONTH) %>%
  summarize(
    FEMALE = sum(FEMALE, na.rm = TRUE),
    MALE = sum(MALE, na.rm = TRUE)
  )

# Print the first few rows of plot_data after summing
print("After summing by month:")
print(head(plot_data))

# Step 2: Add the ratio column
plot_data2 <- plot_data %>%
  mutate(RATIO = MALE / FEMALE) %>%
  filter(!is.infinite(RATIO) & !is.na(RATIO))  # Remove Inf and NA values

# Print the first few rows of plot_data after adding ratio
print("After adding ratio:")
print(head(plot_data))

# Print date range to check
print(paste("Date range:", min(plot_data$MONTH), "to", max(plot_data$MONTH)))

# Calculate the overall average ratio
avg_ratio <- sum(plot_data$MALE) / sum(plot_data$FEMALE)

# Create the plot
ggplot(plot_data2, aes(x = MONTH, y = RATIO)) +
  geom_point(alpha = 0.7, color = "blue", size = 3) +
  geom_hline(yintercept = avg_ratio, linetype = "dashed", color = "red", size = 1) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.05))) +
  scale_x_date(date_breaks = "3 months", date_labels = "%b %Y",
               limits = c(min(plot_data$MONTH), max(plot_data$MONTH))) +
  labs(title = "Monthly Male/Female Ratio Over Time",
       subtitle = "Ratio = Total Males / Total Females per Month",
       x = "Month",
       y = "Male/Female Ratio") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 12),
    axis.title.x = element_text(size = 14),
    axis.title.y = element_text(size = 14)
  ) +
  annotate("text", x = max(plot_data$MONTH), y = avg_ratio, 
           label = paste("Overall Average:", round(avg_ratio, 2)), 
           hjust = 1, vjust = -0.5, color = "red", size = 4)
