# Load required libraries
library(ggplot2)
library(dplyr)
library(pheatmap)
library(grid)
library(tibble)
library(dendextend)

# Set working directory
setwd("/Users/rribeiro/r-analysis/small_heatmap_selected_genes")

# Read data files
dds.selected.genes <- read.table(
  "./deseq-results-selectedgenes.txt",
  header = TRUE,
  sep = '\t',
  stringsAsFactors = FALSE,
  check.names = FALSE
)

Counts <- read.table(
  "./TMM-expression-selected_genes-new.txt",
  header = TRUE,
  sep = '\t',
  stringsAsFactors = FALSE,
  check.names = FALSE
)

# Set row names for both data frames
rownames(dds.selected.genes) <- dds.selected.genes$ids
rownames(Counts) <- Counts$ids

# Extract expression data
sample_columns <- setdiff(colnames(Counts), c("genes", "ids"))
expression_data <- as.matrix(Counts[, sample_columns])
mode(expression_data) <- "numeric"

# Subset expression data for selected genes
selected_gene_ids <- rownames(dds.selected.genes)
expression_data <- expression_data[selected_gene_ids, ]

# Function to extract sample info
extract_sample_info <- function(sample_name) {
  group <- substr(sample_name, 1, 1)
  number <- as.numeric(gsub("^[ABC]([0-9]+).*", "\\1", sample_name))
  sex <- ifelse(grepl("_F$", sample_name), "Female", "Male")
  return(c(group, number, sex))
}

# Create a data frame with sample information
sample_info <- data.frame(
  sample_name = colnames(expression_data),
  do.call(rbind, lapply(colnames(expression_data), extract_sample_info)),
  stringsAsFactors = FALSE
)
colnames(sample_info) <- c("sample_name", "group", "number", "sex")

# Order samples: Female first (sorted by A, B, C), then Male (sorted by A, B, C)
sample_info <- sample_info %>%
  arrange(factor(sex, levels = c("Female", "Male")), group, as.numeric(number))

ordered_samples <- sample_info$sample_name
expression_data <- expression_data[, ordered_samples]

# Create column annotations
annotation_col <- data.frame(
  Sex = factor(sample_info$sex, levels = c("Female", "Male"))
)
rownames(annotation_col) <- ordered_samples

# Log-transform the data
data_transformed <- log2(expression_data + 1)

# Remove genes with zero variance
gene_sd <- apply(data_transformed, 1, sd, na.rm = TRUE)
non_zero_sd_genes <- gene_sd > 0 & !is.na(gene_sd)
data_transformed <- data_transformed[non_zero_sd_genes, ]

# Ensure data_transformed is a numeric matrix
data_transformed <- as.matrix(data_transformed)
mode(data_transformed) <- "numeric"

# Remove rows with NA or infinite values
data_transformed <- data_transformed[apply(data_transformed, 1, function(x) all(is.finite(x))), ]

# Create gene_names vector
gene_names <- dds.selected.genes$genes[non_zero_sd_genes]
rownames(data_transformed) <- gene_names

# Replace periods with underscores in column names
colnames(data_transformed) <- gsub("\\.", "_", colnames(data_transformed))

# Define custom colors for gender annotation
annotation_colors <- list(
  Sex = c("Female" = "#DB009F", "Male" = "#49AD00")
)

# Plot the heatmap and capture the pheatmap object
heatmap_obj <- pheatmap(
  data_transformed,
  scale = "row",
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  show_rownames = TRUE,
  fontsize = 14,
  cluster_cols = TRUE,  # Columns are clustered
  cluster_rows = TRUE,  # Rows are clustered
  silent = TRUE
)

# Modify row labels to italic
row_names_index <- which(heatmap_obj$gtable$layout$name == "row_names")
heatmap_obj$gtable$grobs[[row_names_index]]$gp <- grid::gpar(fontface = "italic")

# Draw the heatmap
grid.newpage()
grid.draw(heatmap_obj$gtable)

# Extract the column dendrogram from the pheatmap object
col_dendrogram <- heatmap_obj$tree_col

# Convert the hclust object to a dendrogram object
col_dendrogram <- as.dendrogram(col_dendrogram)

# Plot the dendrogram as it appears in the heatmap
plot(col_dendrogram, main = "Original Column Dendrogram")

# Now, let's color the dendrogram labels based on 5 clusters
library(dendextend)

# Let's cut the dendrogram into k clusters (k = 5)
k <- 5
clusters <- cutree(heatmap_obj$tree_col, k = k)

# Create a data frame with sample labels and cluster assignments
cluster_assignments <- data.frame(
  Sample = names(clusters),
  Cluster = clusters,
  Sex = annotation_col$Sex[names(clusters)]
)

# Assign colors to clusters for visualization
cluster_colors <- rainbow(k)
names(cluster_colors) <- 1:k

# Color the labels of the original dendrogram based on clusters
col_dendrogram_colored <- col_dendrogram %>%
  set("labels_col", cluster_colors[clusters[labels(col_dendrogram)]])

# Plot the original dendrogram with colored labels
plot(col_dendrogram_colored, main = "Original Column Dendrogram with 5 Cluster Colors")

# Now, manipulate the dendrogram to achieve the desired display
# For example, we can swap certain branches or reorder clusters

# Identify clusters to swap (e.g., clusters 4 and 5)
cluster1 <- 4  # Adjust based on your cluster assignments
cluster2 <- 5

# Get labels for each cluster
labels_cluster1 <- cluster_assignments$Sample[cluster_assignments$Cluster == cluster1]
labels_cluster2 <- cluster_assignments$Sample[cluster_assignments$Cluster == cluster2]
labels_other <- cluster_assignments$Sample[!cluster_assignments$Cluster %in% c(cluster1, cluster2)]

# Construct the new order with all labels
new_order <- c(labels_other, labels_cluster1, labels_cluster2)

# Ensure that new_order contains all labels of the dendrogram
dend_labels <- labels(col_dendrogram)
if (!setequal(new_order, dend_labels)) {
  stop("new_order does not contain all labels of the dendrogram")
}

# Rotate dendrogram to match new order
col_dendrogram_modified <- rotate(col_dendrogram, order = new_order)

# Convert the modified dendrogram back to hclust
col_cluster_modified <- as.hclust(col_dendrogram_modified)

# Color the labels of the modified dendrogram based on clusters
col_dendrogram_modified_colored <- col_dendrogram_modified %>%
  set("labels_col", cluster_colors[clusters[labels(col_dendrogram_modified)]])

# Plot the modified dendrogram with colored labels
plot(col_dendrogram_modified_colored, main = "Modified Column Dendrogram with 5 Cluster Colors")

# Plot the heatmap with the modified dendrogram
heatmap_obj_modified <- pheatmap(
  data_transformed,
  scale = "row",
  cluster_cols = col_cluster_modified,
  cluster_rows = TRUE,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  show_rownames = TRUE,
  fontsize = 14,
  silent = TRUE
)

# Modify row labels to italic
row_names_index <- which(heatmap_obj_modified$gtable$layout$name == "row_names")
heatmap_obj_modified$gtable$grobs[[row_names_index]]$gp <- grid::gpar(fontface = "italic")

# Draw the modified heatmap
grid.newpage()
grid.draw(heatmap_obj_modified$gtable)

