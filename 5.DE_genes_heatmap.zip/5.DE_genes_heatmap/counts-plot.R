# plotting counts per gene
# Load necessary library
library(ggplot2)
library(reshape2)


# Load necessary library
library(ggplot2)

data1 <- data.frame(
  genes = c("lncRNA13944", "MTase11", "KCTD21", "STEN", "DMRT", "LEUCIN", "lncRNA3252"),
  ids = c("TRINITY_DN13944_c0_g1", "TRINITY_DN13329_c0_g3", "TRINITY_DN34979_c0_g1", "TRINITY_DN7346_c0_g1", "TRINITY_DN5895_c0_g1", "TRINITY_DN11569_c0_g1", "TRINITY_DN3252_c0_g1"),
  A13_F = c(3, 2, 1, 0, 3, 1, 1),
  A17_F = c(2, 2, 1, 0, 2, 1, 1),
  A22_F = c(3, 3, 1, 1, 1, 2, 2),
  A24_F = c(5, 2, 2, 2, 1, 1, 1),
  A30_F = c(6, 1, 1, 2, 1, 9, 1),
  B6_F = c(5, 53, 38, 6, 1, 2, 3),
  B7_F = c(5, 9, 4, 3, 1, 1, 3),
  B9_F = c(3, 56, 61, 17, 0, 1, 1),
  B12_F = c(8, 5, 4, 2, 1, 1, 2),
  B13_F = c(5, 224, 122, 88, 0, 1, 1),
  C10_F = c(6, 623, 186, 177, 1, 1, 9),
  C13_F = c(9, 12, 7, 3, 0, 3, 3),
  C14_F = c(6, 102, 82, 51, 0, 1, 1),
  C15_F = c(6, 52, 52, 28, 1, 1, 5),
  C20_F = c(5, 21, 17, 10, 4, 1, 2),
  A20_M = c(0, 6, 1, 1, 7, 1, 2),
  A28_M = c(0, 0, 1, 2, 13, 9, 2),
  A29_M = c(1, 0, 2, 0, 5, 5, 1),
  A31_M = c(0, 0, 1, 1, 2, 2, 1),
  A6_M = c(1, 1, 1, 0, 1, 1, 1),
  B8_M = c(1, 1, 1, 2, 3, 3, 3),
  B11_M = c(1, 1, 1, 3, 3, 572, 62),
  B15_M = c(1, 4, 0, 2, 2, 62, 24),
  B16_M = c(0, 1, 1, 3, 1, 24, 293),
  B19_M = c(0, 2, 0, 2, 2, 293, 11),
  C8_M = c(1, 1, 1, 0, 1, 11, 8),
  C9_M = c(0, 0, 0, 2, 3, 8, 34),
  C11_M = c(0, 1, 1, 3, 2, 34, 23),
  C17_M = c(1, 0, 0, 2, 1, 23, 146),
  C18_M = c(1, 0, 1, 3, 3, 146, 219)
)

data1 <- read.table("/Users/rribeiro/Documents/Ozpolat_Lab/_Projects/Project1-SexDiff/SS-Exp40-50-60-DESEq/deseq2-all/small_heatmap_selected_genes/TMM-expression-selected_genes-new.txt", header = TRUE, sep = '\t') #data1 <- Counts



# Convert the data to long format
library(tidyr)
my_table_long <- pivot_longer(data1, cols = -c(genes, ids), names_to = "Sample", values_to = "Expression")




# Create a new column to identify the groups
my_table_long$Sex <- ifelse(grepl("_M", my_table_long$Sample), "Male", 
                            ifelse(grepl("_F", my_table_long$Sample), "Female", NA))
my_table_long$Size <- ifelse(grepl("^A", my_table_long$Sample), "40S", 
                             ifelse(grepl("^B", my_table_long$Sample), "50S",
                                    ifelse(grepl("^C", my_table_long$Sample), "60S", NA)))

# Convert the data to long format
library(tidyr)
my_table_long <- pivot_longer(my_table_long, cols = -c(genes, ids, Sex), names_to = "Sample", values_to = "Expression")

# Plot dot plot for each gene
ggplot(my_table_long, aes(x = Size, y = Expression, color = Size)) +
  geom_point() +
  facet_grid(genes ~ Sex, scales = "free_y") +
  labs(title = "Dot Plot of Gene Expression",
       x = "Size", y = "Expression")


ggplot(my_table_long, aes(x = Size, y = Expression, color = genes)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  facet_grid(genes ~ Group, scales = "free_y") +
  labs(title = "Dot Plot of Gene Expression with Trend Lines",
       x = "Size", y = "Expression")


# Plot dot plot for each gene, faceted by sex and size, with trend lines and decreased font size
ggplot(my_table_long, aes(x = Size, y = Expression, color = Group)) +
  geom_point(size = 1) +  # Decrease dot size
  geom_smooth(method = "lm", aes(group = 1), se = FALSE, size = 0.5) +  # Decrease line size
  facet_grid(genes ~ Sex, scales = "free_y") +
  labs(title = "Dot Plot of Gene Expression with Trend Lines",
       x = "Size", y = "Expression") +
  theme(text = element_text(size = 6))

ggplot(my_table_long, aes(x = Size, y = Expression, color = Group)) +
  geom_point(size = 1) +  # Decrease dot size
  geom_smooth(method = "loess", aes(group = 1), se = FALSE, size = 0.5) +  # Smooth trend line
  facet_grid(genes ~ Sex, scales = "free_y") +
  labs(title = "Dot Plot of Gene Expression with Trend Lines",
       x = "Size", y = "Expression") +
  theme(text = element_text(size = 6),
        panel.background = element_blank())  # Remove grey background


# Plot dot plot for each gene, faceted by sex and size, with trend lines, decreased font size, reduced stroke, and grey grid lines with no background
ggplot(my_table_long, aes(x = Size, y = Expression, color = genes)) +
  geom_point(size = 1, color = "black") +  # Decrease dot size
  geom_smooth(method = "loess", aes(group = 1), se = FALSE, size = 0.5, color = "black") +  # Smooth trend line
  facet_grid(genes ~ Sex, scales = "free_y") +
  labs(x = "Size", y = "TMM expression") +
  theme(text = element_text(size = 12),
        panel.background = element_blank(),  # Remove background
        panel.grid.major = element_line(color = "lightgrey", size = 0.25),  # Grey grid lines
        panel.grid.minor = element_blank(),  # Remove minor grid lines
        panel.border = element_rect(color = "black", fill = NA, size = 0.25))  # Add border around the grid)  # Remove minor grid lines
