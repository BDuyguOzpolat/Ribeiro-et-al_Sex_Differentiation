library(ggplot2)

# Define the data
data <- data.frame(
  Gene = c("ID13944", "KCD21", "STEN", "ID3252", "MT11", "LEUCIN", "DMRT", "ID13944", "KCD21", "STEN", "ID3252", "MT11", "LEUCIN", "DMRT"),
  ANTERIOR = c(1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1),
  GONIAL = c(1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1),
  TAIL = c(1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1),
  SEX = c("female", "female", "female", "female", "female", "female", "female", "male", "male", "male", "male", "male", "male", "male")
)

# Define colors for the graphical table
colors <- c("white" = "white", "grey" = "grey", "turquoise" = "turquoise")

# Define custom order for 'SEX' column
sex_order <- c("male", "female")

# Create a function to assign colors based on values
assign_color <- function(value) {
  ifelse(value == 0, "grey", "turquoise")
}

# Apply the color function to each cell in the table
data_colors <- data
data_colors[, 2:4] <- apply(data[, 2:4], 2, assign_color)

# Convert the data to long format for plotting
data_long <- tidyr::gather(data_colors, key = "structure", value = "color", -Gene, -SEX)

# Arrange the data by 'SEX' in custom order
data_long <- data_long[order(factor(data_long$SEX, levels = sex_order)), ]

# Plot the graphical table with legend
ggplot(data_long, aes(x = structure, y = Gene, fill = color)) +
  geom_tile(color = "white") +
  scale_fill_manual(values = colors) +
  labs(x = "Structure", y = "Gene", title = "Graphical Table") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~SEX, scales = "free_y") +
  guides(fill = guide_legend(title = "Color"))

