#HCR gonial cluster scoring plotting
# Load required libraries
library(readxl)
library(dplyr)
library(ggplot2)

# Read the Excel file
sten.count <- read_excel("/Users/rribeiro/_hcr-counts/sten-counts.xlsx")

# Convert columns to numeric
sten.count$`STEN+` <- as.numeric(sten.count$`STEN+`)
sten.count$`3252+` <- as.numeric(sten.count$`3252+`)
sten.count$`VASA+` <- as.numeric(sten.count$`VASA+`)

library(dplyr)

# Create a new column with the ratio of STEN+ to VASA+
sten.count <- sten.count %>%
  mutate(ID3252_VASA_ratio = `3252+` / `VASA+`)

# Calculate the mean ratio
mean_ratio <- mean(sten.count$ID3252_VASA_ratio, na.rm = TRUE)

# Calculate the total percentage
total_percentage_ID3252 <- mean_ratio * 100

# Print the total percentage
print(total_percentage_ID3252)

# Check for normality in 'VASA+' column
shapiro.test(sten.count$ID3252_VASA_ratio)

# Histogram
hist(sten.count$ID3252_VASA_ratio, main = "Histogram of ID3252_VASA_ratio", xlab = "STEN_VASA_ratio")

# test Kruskal wallis for each STRUCTURE

# Filter the data for "gonial cluster"
filtered_gonial <- sten.count %>%
  filter(!is.na(ID3252_VASA_ratio), STRUCTURE == "gonial clusters")


kruskal_gonial <- kruskal.test(ID3252_VASA_ratio ~ SEX, data = filtered_gonial)

# Print the result
print(kruskal_gonial)

# Filter the data for "anterior cluster"
filtered_anterior <- sten.count %>%
  filter(!is.na(ID3252_VASA_ratio), STRUCTURE == "anterior cluster")


kruskal_anterior <- kruskal.test(ID3252_VASA_ratio ~ SEX, data = filtered_anterior)

# Print the result
print(kruskal_anterior)

# Filter the data for "tail"
filtered_tail <- sten.count %>%
  filter(!is.na(ID3252_VASA_ratio), STRUCTURE == "tail")


kruskal_tail <- kruskal.test(ID3252_VASA_ratio ~ SEX, data = filtered_tail)

# Print the result
print(kruskal_tail)





##### PLOTTING

library(dplyr)
library(ggplot2)

# Filter out "na" values in the SEX column
# Filter out rows where SEX is "na"
filtered_sten_count <- sten.count %>%
  filter(SEX != "na")

# Create a function to generate plots for each structure
plot_structure <- function(structure_name) {
# Filter data for the given structure
filtered_data <- filtered_sten_count %>%
    filter(STRUCTURE == structure_name)
  
# Calculate the mean ratio and standard error by group of sex
ratio_by_sex <- filtered_data %>%
  group_by(SEX) %>%
  summarize(mean_ratio = mean(ID3252_VASA_ratio, na.rm = TRUE),
            se_ratio = sd(ID3252_VASA_ratio, na.rm = TRUE) / sqrt(n()) * 1.96,
            total_percentage = mean_ratio * 100)
  
# Plotting the bar plot
ggplot(ratio_by_sex, aes(x = SEX, y = mean_ratio, fill = SEX)) +
  geom_bar(stat = "identity", color = "black", width = 0.4) +
  geom_errorbar(aes(ymin = mean_ratio - se_ratio, ymax = mean_ratio + se_ratio), 
                width = 0.1, position = position_dodge(0.9), color = "black") +
  scale_fill_manual(values = c("#DB009F", "#49AD00")) +  # Specify colors for male and female
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
  labs(x = "Sex", y = paste("Ratio of ID3252 to VASA+ (%) -", structure_name), 
       title = paste("ID3252 to VASA+ Ratio -", structure_name)) +
  theme_bw(base_size = 12) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        axis.text.x = element_text(size = 14),
        axis.text.y = element_text(size = 14),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 14),
        plot.title = element_text(size = 16, face = "bold"))
}

# Generate plots for each structure
plot_gonial <- plot_structure("gonial clusters")
plot_anterior <- plot_structure("anterior cluster")
plot_tail <- plot_structure("tail")

# Display the plots
plot_gonial
plot_anterior
plot_tail
