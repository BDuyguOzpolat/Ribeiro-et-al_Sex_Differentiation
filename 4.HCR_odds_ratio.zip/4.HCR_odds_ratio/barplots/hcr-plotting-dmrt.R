# Load required libraries
library(readxl)
library(dplyr)
library(ggplot2)

# Read the Excel file
dmrt.count <- read_excel("/Users/rribeiro/_hcr-counts/dmrt-counts.xlsx")

# Convert columns to numeric
dmrt.count$`DMRT+` <- as.numeric(dmrt.count$`DMRT+`)
dmrt.count$`VASA+` <- as.numeric(dmrt.count$`VASA+`)

# Shapiro-Wilk Test for normality
shapiro_test_result <- shapiro.test(dmrt.count$`DMRT+` / dmrt.count$`VASA+`)

# Perform Kruskal-Wallis test separately for each level of "STRUCTURE"
library(dplyr)

library(broom)

# Define a function to perform Kruskal-Wallis test
kruskal_wrapper <- function(data, group_column) {
  kruskal.test(data$`DMRT+` / data$`VASA+` ~ data[[group_column]])
}

# Apply the Kruskal-Wallis test to each group within a column
kruskal_results <- dmrt.count %>%
  group_by(STRUCTURE) %>%
  do(tidy(kruskal_wrapper(., "PREDICTED SEX")))

# View the results
print(kruskal_results)


library(dunn.test)

# Filter the data for "gonial cluster"
gonial_cluster_data <- dmrt.count %>%
  filter(STRUCTURE == "gonial cluster")

# Perform Dunn's test for "gonial cluster"
dunn_result_gonial <- dunn.test(gonial_cluster_data$`DMRT+` / gonial_cluster_data$`VASA+`, gonial_cluster_data$`PREDICTED SEX`, method = "bonferroni")

# View the result
print(dunn_result_gonial)


# Filter the data for "anterior cluster"
anterior_data <- dmrt.count %>%
  filter(STRUCTURE == "anterior cluster")

# Perform Dunn's test for "anterior cluster"
dunn_result_anterior <- dunn.test(anterior_data$`DMRT+` / anterior_data$`VASA+`, anterior_data$`PREDICTED SEX`, method = "bonferroni")

# View the result
print(dunn_result_anterior)

# Filter the data for "tail"
tail_data <- dmrt.count %>%
  filter(STRUCTURE == "tail")

# Perform Dunn's test for "gonial cluster"
dunn_result_tail <- dunn.test(tail_data$`DMRT+` / tail_data$`VASA+`, tail_data$`PREDICTED SEX`, method = "bonferroni")

# View the result
print(dunn_result_tail)


## GONIAL CLUSTER PLOT
# Calculate percentage of males and females, handling NA values
gender_percentage <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`)) %>%
  filter(STRUCTURE == "gonial cluster") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(total_count = n()) %>%
  mutate(percentage = total_count / sum(total_count) * 100)

# GONIAL CLUSTERS: Calculate mean and standard error for the ratio between DMRT+ and VASA+ for each gender, handling NA values
se_data <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`) & !is.na(`DMRT+`) & !is.na(`VASA+`) & STRUCTURE == "gonial cluster") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(mean_ratio = mean(`DMRT+` / `VASA+`), 
            se_ratio = sd(`DMRT+` / `VASA+`) / sqrt(n()))

# Merge percentage and ratio data
merged_data <- merge(gender_percentage, se_data, by = "PREDICTED SEX")

# Plotting with standard errors
ggplot(merged_data, aes(x = `PREDICTED SEX`, y = mean_ratio, fill = `PREDICTED SEX`)) +
  geom_bar(stat = "identity", color = "black", fill = "black", width = 0.6) +
  geom_errorbar(aes(ymin = mean_ratio - se_ratio, ymax = mean_ratio + se_ratio), 
                width = 0.2, position = position_dodge(0.9), color = "black") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
  labs(x = "Sex", y = "DMRT+ gonial clusters (%)", 
       title = "DMRT+ gonial clusters",
       title.size = 16,
       xlab = "Sex", ylab = "Ratio of DMRT+ to VASA+ (%)") +
  theme_bw(base_size = 14) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        plot.title = element_text(size = 16, face = "bold"))

## ANTERIOR CLUSTER PLOT
# Calculate percentage of males and females, handling NA values
gender_percentage_anterior <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`)) %>%
  filter(STRUCTURE == "anterior cluster") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(total_count = n()) %>%
  mutate(percentage = total_count / sum(total_count) * 100)

# Calculate mean and standard error for the ratio between DMRT+ and VASA+ for each gender, handling NA values
se_data_anterior <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`) & !is.na(`DMRT+`) & !is.na(`VASA+`) & STRUCTURE == "anterior cluster") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(mean_ratio = mean(`DMRT+` / `VASA+`), 
            se_ratio = sd(`DMRT+` / `VASA+`) / sqrt(n()))

# Merge percentage and ratio data
merged_data_anterior <- merge(gender_percentage_anterior, se_data_anterior, by = "PREDICTED SEX")

# Plotting with standard errors
ggplot(merged_data_anterior, aes(x = `PREDICTED SEX`, y = mean_ratio, fill = `PREDICTED SEX`)) +
  geom_bar(stat = "identity", color = "black", fill = "black", width = 0.6) +
  geom_errorbar(aes(ymin = mean_ratio - se_ratio, ymax = mean_ratio + se_ratio), 
                width = 0.2, position = position_dodge(0.9), color = "black") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
  labs(x = "Sex", y = "DMRT+ anterior clusters (%)", 
       title = "DMRT+ anterior clusters",
       title.size = 16,
       xlab = "Sex", ylab = "Ratio of DMRT+ to VASA+ (%)") +
  theme_bw(base_size = 14) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        plot.title = element_text(size = 16, face = "bold"))


## TAIL PLOT
# Calculate percentage of males and females, handling NA values
gender_percentage_tail <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`)) %>%
  filter(STRUCTURE == "tail") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(total_count = n()) %>%
  mutate(percentage = total_count / sum(total_count) * 100)

# GONIAL CLUSTERS: Calculate mean and standard error for the ratio between DMRT+ and VASA+ for each gender, handling NA values
se_data_tail <- dmrt.count %>%
  filter(!is.na(`PREDICTED SEX`) & !is.na(`DMRT+`) & !is.na(`VASA+`) & STRUCTURE == "tail") %>%
  group_by(`PREDICTED SEX`) %>%
  summarize(mean_ratio = mean(`DMRT+` / `VASA+`), 
            se_ratio = sd(`DMRT+` / `VASA+`) / sqrt(n()))

# Merge percentage and ratio data
merged_data_tail <- merge(gender_percentage_tail, se_data_tail, by = "PREDICTED SEX")

# Plotting with standard errors
ggplot(merged_data_tail, aes(x = `PREDICTED SEX`, y = mean_ratio, fill = `PREDICTED SEX`)) +
  geom_bar(stat = "identity", color = "black", fill = "black", width = 0.6) +
  geom_errorbar(aes(ymin = mean_ratio - se_ratio, ymax = mean_ratio + se_ratio), 
                width = 0.2, position = position_dodge(0.9), color = "black") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
  labs(x = "Sex", y = "DMRT+ tails (%)", 
       title = "DMRT+ tails",
       title.size = 16,
       xlab = "Sex", ylab = "Ratio of DMRT+ to VASA+ (%)") +
  theme_bw(base_size = 14) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        legend.position = "none",
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14),
        plot.title = element_text(size = 16, face = "bold"))


