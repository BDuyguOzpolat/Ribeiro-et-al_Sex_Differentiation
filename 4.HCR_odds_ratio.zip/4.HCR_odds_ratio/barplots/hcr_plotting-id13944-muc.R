#HCR gonial cluster scoring plotting
# Load required libraries
library(readxl)
library(dplyr)
library(ggplot2)

# Read the Excel file
muc <- read_excel("/Users/rribeiro/_hcr-counts/13944-muc-counts.xlsx")

# Convert columns to numeric
muc$`13944+` <- as.numeric(muc$`13944+`)
muc$`VASA+` <- as.numeric(muc$`VASA+`)
muc$`MUCIN+` <- as.numeric(muc$`MUCIN+`)

# Create a new column with the ratio of ID13944+ to VASA+
muc <- muc %>%
  mutate(ID13944_VASA_ratio = `13944+` / `VASA+`)

# Create a new column with the ratio of ID13944+ to VASA+
muc <- muc %>%
  mutate(MUCIN_VASA_ratio = `MUCIN+` / `VASA+`)

# Check for normality in ID13944_VASA_ratio column
shapiro.test(muc$ID13944_VASA_ratio)

# Check for normality in MUCIN_VASA_ratio column
shapiro.test(muc$MUCIN_VASA_ratio)

# Histogram
hist(muc$KCD21_VASA_ratio, main = "Histogram of KCD21_VASA_ratio", xlab = "kcd21_VASA_ratio")


##### ID13944
# test Kruskal wallis for each STRUCTURE

# Filter the data for "gonial cluster"
filtered_gonial_ID <- muc %>%
  filter(!is.na(ID13944_VASA_ratio), STRUCTURE == "gonial clusters")


kruskal_gonial_ID <- kruskal.test(ID13944_VASA_ratio ~ `PREDICTED SEX`, data = filtered_gonial_ID)

# Print the result
print(kruskal_gonial_ID)

# Filter the data for "anterior cluster"
filtered_anterior_ID <- muc %>%
  filter(!is.na(ID13944_VASA_ratio), STRUCTURE == "anterior cluster")


kruskal_anterior_ID <- kruskal.test(ID13944_VASA_ratio ~ `PREDICTED SEX`, data = filtered_anterior_ID)

# Print the result
print(kruskal_anterior_ID)

# Filter the data for "tail"
filtered_tail_ID <- muc %>%
  filter(!is.na(ID13944_VASA_ratio), STRUCTURE == "tail")


kruskal_tail_ID <- kruskal.test(ID13944_VASA_ratio ~ `PREDICTED SEX`, data = filtered_tail_ID)

# Print the result
print(kruskal_tail_ID)


## Calculating percentages


library(dplyr)
# Combine the columns 'HCR#' and 'IND'
wormID <- paste(muc$`HCR#`, muc$IND, sep = " ")

# You can then assign the combined column back to your dataframe or use it as needed
muc <- cbind(muc, wormID)


# Calculate the mean ratio, total percentage, number of individuals, and number of observations by PREDICTED SEX and STRUCTURE
summary_by_sex_structure <- muc %>%
  group_by(`PREDICTED SEX`, STRUCTURE) %>%
  summarize(mean_ratio = mean(ID13944_VASA_ratio, na.rm = TRUE),
            total_percentage = mean_ratio * 100,
            n_individuals = n_distinct(wormID),  # Count of unique individuals
            n_observations = n())  # Count of observations

# Print the summary
print(summary_by_sex_structure)


##### PLOTTING

library(dplyr)
library(ggplot2)

# Filter out "na" values in the SEX column
# Filter out rows where SEX is "na"
filtered_muc_count <- muc %>%
  filter(`PREDICTED SEX` != "na")

# Create a function to generate plots for each structure
plot_structure <- function(structure_name) {
  # Filter data for the given structure
  filtered_data <- filtered_muc_count %>%
    filter(STRUCTURE == structure_name)
  
  # Calculate the mean ratio and standard error by group of sex
  ratio_by_sex <- filtered_data %>%
    group_by(`PREDICTED SEX`) %>%
    summarize(mean_ratio = mean(ID13944_VASA_ratio, na.rm = TRUE),
              se_ratio = sd(ID13944_VASA_ratio, na.rm = TRUE) / sqrt(n()) * 1.96,
              total_percentage = mean_ratio * 100)
  
  # Plotting the bar plot
  ggplot(ratio_by_sex, aes(x = `PREDICTED SEX`, y = mean_ratio, fill = `PREDICTED SEX`)) +
    geom_bar(stat = "identity", color = "black", width = 0.4) +
    geom_errorbar(aes(ymin = mean_ratio - se_ratio, ymax = mean_ratio + se_ratio), 
                  width = 0.1, position = position_dodge(0.9), color = "black") +
    scale_fill_manual(values = c("#DB009F", "#49AD00", "black")) +  # Specify colors for male and female
    scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
    labs(x = "Sex", y = paste("Ratio of ID13944 to VASA+ (%) -", structure_name), 
         title = paste("ID13944 to VASA+ Ratio -", structure_name)) +
    theme_bw(base_size = 12) +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.line = element_line(colour = "black"),
          legend.position = "none",
          axis.text.x = element_text(size = 14),
          axis.text.y = element_text(size = 14),
          axis.title.x = element_text(size = 16),
          axis.title.y = element_text(size = 14),
          plot.title = element_text(size = 16, face = "bold"))
}

# Generate plots for each structure
plot_gonial_ID <- plot_structure("gonial clusters")
plot_anterior_ID <- plot_structure("anterior cluster")
plot_tail_ID <- plot_structure("tail")

# Display the plots
plot_gonial_ID
plot_anterior_ID
plot_tail_ID



###################################################
##### MUCIN

# test Kruskal wallis for each STRUCTURE

# Filter the data for "gonial cluster"
filtered_gonial <- muc %>%
  filter(!is.na(MUCIN_VASA_ratio), STRUCTURE == "gonial clusters")


kruskal_gonial <- kruskal.test(MUCIN_VASA_ratio ~ `PREDICTED SEX`, data = filtered_gonial)

# Print the result
print(kruskal_gonial)

# Filter the data for "anterior cluster"
filtered_anterior <- muc %>%
  filter(!is.na(MUCIN_VASA_ratio), STRUCTURE == "anterior cluster")


kruskal_anterior <- kruskal.test(MUCIN_VASA_ratio ~ `PREDICTED SEX`, data = filtered_anterior)

# Print the result
print(kruskal_anterior)

# Filter the data for "tail"
filtered_tail <- muc %>%
  filter(!is.na(MUCIN_VASA_ratio), STRUCTURE == "tail")


kruskal_tail <- kruskal.test(MUCIN_VASA_ratio ~ `PREDICTED SEX`, data = filtered_tail)

# Print the result
print(kruskal_tail)


##### PLOTTING

library(dplyr)
library(ggplot2)

# Filter out "na" values in the SEX column
# Create a function to generate plots for each structure
plot_structure <- function(structure_name) {
  # Filter data for the given structure
  filtered_data <- filtered_muc_count %>%
    filter(STRUCTURE == structure_name)
  
  # Calculate the mean ratio, standard error, and number of observations by group of sex
  ratio_by_sex <- filtered_data %>%
    group_by(`PREDICTED SEX`) %>%
    summarize(mean_ratio = mean(MUCIN_VASA_ratio, na.rm = TRUE),
              se_ratio = sd(MUCIN_VASA_ratio, na.rm = TRUE) / sqrt(n()) * 1.96,
              total_percentage = mean_ratio * 100,
              n_obs = n())  # Add the number of observations
  
# Plotting the bar plot
  ggplot(ratio_by_sex, aes(x = `PREDICTED SEX`, y = mean_ratio, fill = `PREDICTED SEX`)) +
    geom_bar(stat = "identity", color = "black", width = 0.4) +
    geom_errorbar(aes(ymin = pmax(mean_ratio - se_ratio, 0), ymax = mean_ratio + se_ratio), 
                  width = 0.1, position = position_dodge(0.9), color = "black") +
    geom_text(aes(label = paste("Nob =", n_obs)), vjust = 1.5, size = 4, position = position_dodge(0.9)) +  # Add text for number of observations
    scale_fill_manual(values = c("#DB009F", "#49AD00", "black")) +  # Specify colors for male and female
    scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +  
    labs(x = "Sex", y = paste("Ratio of MUCIN to VASA+ (%) -", structure_name), 
         title = paste("MUCIN to VASA+ Ratio -", structure_name)) +
    theme_bw(base_size = 12) +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.line = element_line(colour = "black"),
          legend.position = "none",
          axis.text.x = element_text(size = 14),
          axis.text.y = element_text(size = 14),
          axis.title.x = element_text(size = 16),
          axis.title.y = element_text(size = 14),
          plot.title = element_text(size = 16, face = "bold"))
}
# Generate plots for each structure
plot_gonial <- plot_structure("gonial clusters")
plot_anterior <- plot_structure("anterior cluster")
plot_tail <- plot_structure("tail")

# Display the plots
plot_gonial
plot_anterior
plot_tail




