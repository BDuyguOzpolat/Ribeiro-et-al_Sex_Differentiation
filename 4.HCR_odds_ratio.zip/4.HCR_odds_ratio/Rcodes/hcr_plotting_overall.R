#HCR gonial cluster scoring plotting
# Load required libraries
library(readxl)
library(dplyr)
library(ggplot2)

# Read the Excel file
all.counts <- read_excel("/Users/rribeiro/_hcr-counts/all_counts.xlsx")

# Convert columns to numeric
all.counts$`DMRT+` <- as.numeric(all.counts$`DMRT+`)
all.counts$`13944+` <- as.numeric(all.counts$`13944+`)
all.counts$`MT11+` <- as.numeric(all.counts$`MT11+`)
all.counts$`MUCIN+` <- as.numeric(all.counts$`MUCIN+`)
all.counts$`LEUCIN+` <- as.numeric(all.counts$`LEUCIN+`)
all.counts$`VASA+` <- as.numeric(all.counts$`VASA+`)
all.counts$`PRMI+` <- as.numeric(all.counts$`PRMI+`)
all.counts$`3252+` <- as.numeric(all.counts$`3252+`)
all.counts$`KCD21+` <- as.numeric(all.counts$`KCD21+`)
all.counts$`STEN+` <- as.numeric(all.counts$`STEN+`)


# Combine the columns 'HCR#' and 'IND'
wormID <- paste(all.counts$`HCR#`, all.counts$IND, all.counts$NSEGMENTS, sep = " ")

# You can then assign the combined column back to your dataframe or use it as needed
all.counts <- cbind(all.counts, wormID)

# Assuming your dataframe is named "all.counts"
# Calculate ratios of each column divided by '`VASA+`'
all.counts$ratio_MUCIN <- all.counts$`MUCIN+` / all.counts$`VASA+`
all.counts$ratio_13944 <- all.counts$`13944+` / all.counts$`VASA+`
all.counts$ratio_KCD21 <- all.counts$`KCD21+` / all.counts$`VASA+`
all.counts$ratio_STEN <- all.counts$`STEN+` / all.counts$`VASA+`
all.counts$ratio_3252 <- all.counts$`3252+` / all.counts$`VASA+`
all.counts$ratio_MT11 <- all.counts$`MT11+` / all.counts$`VASA+`
all.counts$ratio_LEUCIN <- all.counts$`LEUCIN+` / all.counts$`VASA+`
all.counts$ratio_DMRT <- all.counts$`DMRT+` / all.counts$`VASA+`
all.counts$ratio_PRMI <- all.counts$`PRMI+` / all.counts$`VASA+`

#Save modified data
all.counts.modified <- all.counts

write.csv(all.counts.modified, "/Users/rribeiro/_hcr-counts/all.counts.apr24.csv", row.names = FALSE)

library(dplyr)

# Define a function to calculate summary statistics for a given ratio column
calculate_summary <- function(all.counts, ratio_column) {
  all.counts %>%
    filter(!is.na({{ratio_column}})) %>%  
    group_by(SEX, STRUCTURE) %>%
    summarize(mean_ratio = mean({{ratio_column}}, na.rm = TRUE),
              sd_ratio = sd({{ratio_column}}, na.rm = TRUE),
              total_percentage = mean({{ratio_column}}, na.rm = TRUE) * 100,
              n_individuals = n_distinct(wormID),
              n_observations = n())  
}

# List of ratio column names
ratio_columns <- c("ratio_MUCIN", "ratio_13944", "ratio_KCD21", "ratio_STEN", 
                   "ratio_3252", "ratio_MT11", "ratio_LEUCIN", 
                   "ratio_DMRT", "ratio_PRMI")

# Apply the function to each ratio column and bind the results together
summary_statistics <- lapply(ratio_columns, function(ratio_column) {
  calculate_summary(all.counts, !!sym(ratio_column))
})

# Combine the results into a single dataframe
summary_res <- bind_rows(summary_statistics, .id = "column_name")

# Rename the column_name column to the corresponding ratio column name
summary_res$column_name <- factor(summary_res$column_name, levels = as.character(1:length(ratio_columns)), labels = ratio_columns)

# Print the summary
print(summary_res)

# Write the summary to a CSV file
write.csv(summary_res, "/Users/rribeiro/_hcr-counts/summary_res_apr24.csv", row.names = FALSE)


#######################################################
############### STATISTICS
# Check for normality in ID13944_VASA_ratio column
shapiro.test(all.counts$ratio_MUCIN)
shapiro.test(all.counts$ratio_13944)
shapiro.test(all.counts$ratio_KCD21)
shapiro.test(all.counts$ratio_DMRT)
shapiro.test(all.counts$ratio_MT11)
shapiro.test(all.counts$ratio_LEUCIN)
shapiro.test(all.counts$ratio_PRMI)
shapiro.test(all.counts$ratio_3252)
shapiro.test(all.counts$ratio_STEN)

#######################################################
############### Graphical Table
library(dplyr)
library(tidyr)

# Your original code
summary_DMRT <- all.counts %>%
  filter(grepl("DMRT", EXPERIMENT, ignore.case = TRUE)) %>%  
  group_by(wormID, SEX, STRUCTURE) %>%
  summarize(
    mean_ratio_DMRT = mean(ratio_DMRT, na.rm = TRUE)
  )

# Pivot the table
summary_pivoted <- summary_DMRT %>%
  pivot_wider(names_from = STRUCTURE, values_from = mean_ratio_DMRT)

# Print the pivoted table
print(summary_pivoted)

# Write the summary to a CSV file
write.csv(summary_pivoted, "/Users/rribeiro/_hcr-counts/summary_DMRT.csv", row.names = FALSE)



#### Graphical table plot
library(ggplot2)

# Define colors for the graphical table
colors <- c("white" = "white", "grey" = "grey", "coral1" = "coral1")

# Define custom order for 'SEX' column
sex_order <- c("MALE", "FEMALE", "UNKNOWN")

# Create a function to assign colors based on values
assign_color <- function(value) {
  ifelse(is.na(value), "white", ifelse(value == 0, "grey", "coral1"))
}

# Apply the color function to each cell in the table
summary_pivoted_colors <- summary_pivoted
summary_pivoted_colors[, -c(1, 2)] <- apply(summary_pivoted_colors[, -c(1, 2)], 2, assign_color)

# Convert the data to long format for plotting
summary_pivoted_long <- tidyr::gather(summary_pivoted_colors, key = "structure", value = "color", -wormID, -SEX)

# Arrange the data by 'SEX' in custom order
summary_pivoted_long <- summary_pivoted_long[order(factor(summary_pivoted_long$SEX, levels = sex_order)), ]

# Plot the graphical table with legend
ggplot(summary_pivoted_long, aes(x = structure, y = wormID, fill = color)) +
  geom_tile(color = "white") +
  scale_fill_manual(values = colors, labels = c("Present", "Absent", "Not found")) +
  labs(x = "Structure", y = "Worm ID", title = "Graphical Table of Mean Ratio DMRT") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~SEX, scales = "free_y") +
  guides(fill = guide_legend(title = "Color"))

#################################################
#######  ODDS RATIO

# Assuming your dataframe is named "all.counts"
# Calculate ratios of each column divided by '`VASA+`'
all.counts$MUCIN.minus <- all.counts$`VASA+` - all.counts$`MUCIN+` 
all.counts$ID13944.minus <- all.counts$`VASA+` - all.counts$`13944+` 
all.counts$KCD21.minus <- all.counts$`VASA+` - all.counts$`KCD21+` 
all.counts$STEN.minus <- all.counts$`VASA+` - all.counts$`STEN+` 
all.counts$ID3252.minus <- all.counts$`VASA+` - all.counts$`3252+` 
all.counts$MT11.minus <- all.counts$`VASA+` - all.counts$`MT11+` 
all.counts$LEUCIN.minus <- all.counts$`VASA+` - all.counts$`LEUCIN+` 
all.counts$DMRT.minus <- all.counts$`VASA+` - all.counts$`DMRT+` 
all.counts$PRMI.minus <- all.counts$`VASA+`- all.counts$`PRMI+` 



# odds ratios
library(epitools)
library(broom)

# 1. Filter the data to only include rows with "gonial cluster" in the STRUCTURE column
gonial_cluster <- all.counts[all.counts$STRUCTURE == "gonial cluster", ]

# 2. Calculate the total sum for presence and absence of each gene, separated by sex
gene_totals <- data.frame(
  Gene = c("MUCIN", "ID13944", "KCD21", "STEN", "ID3252", "MT11", "LEUCIN", "DMRT", "PRMI"),
  Male_Presence = sapply(c("MUCIN+", "13944+", "KCD21+", "STEN+", "3252+", "MT11+", "LEUCIN+", "DMRT+", "PRMI+"), 
                         function(x) sum(gonial_cluster[gonial_cluster$SEX == "male", x], na.rm = TRUE)),
  Male_Absence = sapply(c("MUCIN.minus", "ID13944.minus", "KCD21.minus", "STEN.minus", "ID3252.minus", "MT11.minus", "LEUCIN.minus", "DMRT.minus", "PRMI.minus"), 
                        function(x) sum(gonial_cluster[gonial_cluster$SEX == "male", x], na.rm = TRUE)),
  Female_Presence = sapply(c("MUCIN+", "13944+", "KCD21+", "STEN+", "3252+", "MT11+", "LEUCIN+", "DMRT+", "PRMI+"), 
                           function(x) sum(gonial_cluster[gonial_cluster$SEX == "female", x], na.rm = TRUE)),
  Female_Absence = sapply(c("MUCIN.minus", "ID13944.minus", "KCD21.minus", "STEN.minus", "ID3252.minus", "MT11.minus", "LEUCIN.minus", "DMRT.minus", "PRMI.minus"), 
                          function(x) sum(gonial_cluster[gonial_cluster$SEX == "female", x], na.rm = TRUE))
)


write.csv(gene_totals, "/Users/rribeiro/_hcr-counts/odds-ratio/odds_gonial_clusters.csv", row.names = FALSE)


# 3. Create contingency tables and calculate odds ratios for each gene
library(epitools)
library(broom)

# For each gene, calculate: 
male_presence <- 2
male_absence <- 3
female_presence <- 6 
female_absence <- 1

# Create the contingency table
contingency_table <- matrix(c(male_presence, female_presence, 
                                      male_absence, female_absence), 
                                    nrow = 2, ncol = 2, 
                                    dimnames = list(c("Males", "Females"), 
                                                    c("Present", "Absent")))

# Calculate odds ratio and 95% confidence interval
#calculate odds ratio
oddsratio(contingency_table)


# Log the results to a table for plotting a forest plot.

