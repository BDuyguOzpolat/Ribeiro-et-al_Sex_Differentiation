library(ggplot2)
library(readr)

# Load the CSV file
gene_data <- read_csv("/Users/rribeiro/_hcr-counts/odds-ratio/odds-ratio-table-tail.csv")

# Calculate the odds ratio and confidence interval
gene_data$Odds_Ratio <- gene_data$or
gene_data$CI_Lower <- gene_data$lower
gene_data$CI_Upper <- gene_data$upper

# Define a significance threshold (e.g., p-value < 0.05)
significance_threshold <- 0.05

# Create the forest plot with significance indicators
ggplot(gene_data, aes(x = Odds_Ratio, y = reorder(Gene, Odds_Ratio))) +
  geom_point(color = ifelse(gene_data$midp.exact < significance_threshold, "red", "black")) +
  geom_errorbarh(aes(xmin = CI_Lower, xmax = CI_Upper), height = 0.2) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey") +
  labs(x = "Odds Ratio", y = "Gene") +
  theme_minimal() +
  annotate("text", x = Inf, y = gene_data$Gene, label = ifelse(gene_data$midp.exact < significance_threshold, "*", ""), 
           hjust = 1.1, size = 5, color = ifelse(gene_data$midp.exact < significance_threshold, "red", "black"))



# Calculate the odds ratio and confidence interval
gene_data <- gene_data %>%
  mutate(Odds_Ratio = or,
         CI_Lower = ifelse(is.na(lower), 0, lower),  # Replace NA with 0 for lower CI
         CI_Upper = ifelse(is.na(upper), Inf, upper),  # Replace NA with Inf for upper CI
         Odds_Ratio_Transformed = case_when(
           Odds_Ratio > 1 ~ log(Odds_Ratio, base = exp(1)),
           Odds_Ratio < 1 ~ -log(1/Odds_Ratio, base = exp(1)),
           TRUE ~ 0
         ),
         CI_Lower_Transformed = case_when(
           Odds_Ratio > 1 ~ log(CI_Lower, base = exp(1)),
           Odds_Ratio < 1 ~ -log(1/CI_Upper, base = exp(1)),
           TRUE ~ 0
         ),
         CI_Upper_Transformed = case_when(
           Odds_Ratio > 1 ~ log(CI_Upper, base = exp(1)),
           Odds_Ratio < 1 ~ -log(1/CI_Lower, base = exp(1)),
           TRUE ~ 0
         ),
         N = Male_Presence + Male_Absence + Female_Presence + Female_Absence,
         Significance = case_when(
           midp.exact < 0.001 ~ "***",
           midp.exact < 0.01 ~ "**",
           midp.exact < 0.05 ~ "*",
           TRUE ~ ""
         ))

# Create the forest plot with transformed odds ratios and significance indicators
ggplot(gene_data, aes(x = Odds_Ratio_Transformed, y = reorder(Gene, Odds_Ratio_Transformed))) +
  geom_point(aes(color = ifelse(midp.exact < 0.05, "Significant", "Not Significant"))) +
  geom_errorbarh(aes(xmin = CI_Lower_Transformed, xmax = CI_Upper_Transformed), height = 0.2) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +
  labs(x = "Transformed Odds Ratio Posterior Growth Zone", y = "Gene", color = "Significance") +
  scale_color_manual(values = c("Significant" = "red", "Not Significant" = "black")) +
  scale_x_continuous(limits = c(-7, 7)) +
  theme_minimal() +
  annotate("text", x = Inf, y = gene_data$Gene, label = paste0(gene_data$Significance, " (N = ", gene_data$N, ")"),
           hjust = 1.1, size = 3, color = ifelse(gene_data$midp.exact < 0.05, "red", "black"))
